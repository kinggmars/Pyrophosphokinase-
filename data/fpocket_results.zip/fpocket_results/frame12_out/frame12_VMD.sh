#!/bin/bash
vmd frame12_out.pdb -e frame12.tcl
