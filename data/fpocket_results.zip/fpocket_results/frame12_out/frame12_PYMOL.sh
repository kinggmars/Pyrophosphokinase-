#!/bin/bash
pymol frame12.pml
