#!/bin/bash
vmd frame9_out.pdb -e frame9.tcl
