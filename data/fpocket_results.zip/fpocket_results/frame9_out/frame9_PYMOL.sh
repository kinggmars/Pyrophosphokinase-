#!/bin/bash
pymol frame9.pml
