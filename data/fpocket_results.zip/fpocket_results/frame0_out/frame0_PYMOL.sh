#!/bin/bash
pymol frame0.pml
