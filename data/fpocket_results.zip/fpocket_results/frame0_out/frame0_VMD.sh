#!/bin/bash
vmd frame0_out.pdb -e frame0.tcl
