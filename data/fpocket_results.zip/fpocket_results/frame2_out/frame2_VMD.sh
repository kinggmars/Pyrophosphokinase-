#!/bin/bash
vmd frame2_out.pdb -e frame2.tcl
