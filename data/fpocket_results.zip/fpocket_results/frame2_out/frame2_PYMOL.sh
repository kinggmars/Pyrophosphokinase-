#!/bin/bash
pymol frame2.pml
