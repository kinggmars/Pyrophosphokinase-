#!/bin/bash
vmd frame4_out.pdb -e frame4.tcl
