#!/bin/bash
pymol frame4.pml
