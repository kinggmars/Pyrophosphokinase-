#!/bin/bash
vmd frame7_out.pdb -e frame7.tcl
