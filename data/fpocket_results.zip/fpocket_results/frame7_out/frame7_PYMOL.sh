#!/bin/bash
pymol frame7.pml
