#!/bin/bash
vmd EX_473_out.pdb -e EX_473.tcl
