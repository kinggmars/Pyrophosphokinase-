#!/bin/bash
pymol EX_473.pml
