#!/bin/bash
pymol EX_246.pml
