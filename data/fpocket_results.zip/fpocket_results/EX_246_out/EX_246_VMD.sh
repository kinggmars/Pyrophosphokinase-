#!/bin/bash
vmd EX_246_out.pdb -e EX_246.tcl
