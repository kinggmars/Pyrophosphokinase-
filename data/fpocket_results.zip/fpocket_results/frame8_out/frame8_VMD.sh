#!/bin/bash
vmd frame8_out.pdb -e frame8.tcl
