#!/bin/bash
pymol frame8.pml
