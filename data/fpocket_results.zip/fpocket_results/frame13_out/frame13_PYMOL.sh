#!/bin/bash
pymol frame13.pml
