#!/bin/bash
vmd frame13_out.pdb -e frame13.tcl
