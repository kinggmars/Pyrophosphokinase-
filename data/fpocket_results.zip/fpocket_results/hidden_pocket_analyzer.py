#!/usr/bin/env python3
"""
universal_hidden_pocket_analyzer.py

通用多构象隐藏口袋识别与分析
支持任意数量构象，自动检测和解析
"""

import os
import re
import sys
import json
import argparse
import numpy as np
import pandas as pd
from pathlib import Path
from collections import defaultdict, Counter
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
import warnings
warnings.filterwarnings('ignore')

plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

class UniversalFpocketParser:
    """通用fpocket解析器"""
    
    @staticmethod
    def parse_info_file(info_file):
        """解析fpocket的info.txt文件"""
        pockets = []
        
        try:
            with open(info_file, 'r') as f:
                content = f.read()
            
            # 分割不同口袋的信息
            pocket_sections = content.split('Pocket ')[1:]  # 第一个是空字符串
            
            for section in pocket_sections:
                lines = section.strip().split('\n')
                if not lines:
                    continue
                
                # 提取口袋编号
                pocket_num = int(lines[0].strip().split(':')[0])
                
                # 初始化口袋字典
                pocket_info = {'pocket_id': pocket_num}
                
                # 解析每个字段
                for line in lines:
                    line = line.strip()
                    if not line:
                        continue
                    
                    # 处理每个字段
                    if 'Score :' in line:
                        pocket_info['score'] = float(line.split(':')[1].strip())
                    elif 'Druggability Score :' in line:
                        pocket_info['druggability'] = float(line.split(':')[1].strip())
                    elif 'Drug score :' in line:
                        pocket_info['druggability'] = float(line.split(':')[1].strip())
                    elif 'Volume :' in line:
                        pocket_info['volume'] = float(line.split(':')[1].strip())
                    elif 'Hydrophobicity score:' in line:
                        pocket_info['hydrophobicity'] = float(line.split(':')[1].strip())
                    elif 'Number of Alpha Spheres :' in line:
                        pocket_info['num_spheres'] = int(line.split(':')[1].strip())
                    elif 'Total SASA :' in line:
                        pocket_info['sasa'] = float(line.split(':')[1].strip())
                
                pockets.append(pocket_info)
                
        except Exception as e:
            print(f"解析info.txt文件时出错: {e}")
        
        return pockets
    
    @staticmethod
    def calculate_pocket_center(pdb_file):
        """从口袋的PDB文件计算几何中心"""
        coords = []
        
        try:
            with open(pdb_file, 'r') as f:
                for line in f:
                    if line.startswith("ATOM") or line.startswith("HETATM"):
                        try:
                            x = float(line[30:38].strip())
                            y = float(line[38:46].strip())
                            z = float(line[46:54].strip())
                            coords.append([x, y, z])
                        except (ValueError, IndexError):
                            continue
            
            if coords:
                coords_array = np.array(coords)
                center = np.mean(coords_array, axis=0)
                return center.tolist()
            else:
                return [0.0, 0.0, 0.0]
                
        except Exception as e:
            print(f"计算口袋中心时出错 {pdb_file}: {e}")
            return [0.0, 0.0, 0.0]
    
    @staticmethod
    def parse_fpocket_directory(fpocket_dir, weight=1.0, name=None, min_score=None):
        """解析整个fpocket输出目录"""
        fpocket_dir = Path(fpocket_dir)
        
        # 检查目录是否存在
        if not fpocket_dir.exists():
            print(f"警告: fpocket目录不存在: {fpocket_dir}")
            return []
        
        # 使用目录名作为默认名称
        if name is None:
            name = fpocket_dir.name
        
        # 查找info.txt文件
        info_files = list(fpocket_dir.glob("*_info.txt")) + list(fpocket_dir.glob("info.txt"))
        
        if not info_files:
            print(f"警告: 在 {fpocket_dir} 中未找到info.txt文件")
            return []
        
        info_file = info_files[0]
        print(f"解析文件: {info_file}")
        
        # 解析info.txt
        pockets = UniversalFpocketParser.parse_info_file(info_file)
        
        # 应用评分筛选
        original_count = len(pockets)
        if min_score is not None:
            filtered_pockets = []
            for pocket in pockets:
                if pocket.get('score', -999) >= min_score:
                    filtered_pockets.append(pocket)
            
            pockets = filtered_pockets
            print(f"  评分筛选: {original_count} -> {len(pockets)} (阈值: {min_score})")
        
        # 查找pockets目录
        pockets_dir = fpocket_dir / "pockets"
        if not pockets_dir.exists():
            pockets_dir = fpocket_dir
        
        # 为每个口袋计算中心坐标
        for pocket in pockets:
            pocket_id = pocket['pocket_id']
            
            # 查找对应的PDB文件
            pdb_patterns = [
                pockets_dir / f"pocket{pocket_id}_atm.pdb",
                pockets_dir / f"pocket{pocket_id}.pdb",
                fpocket_dir / f"pocket{pocket_id}_atm.pdb"
            ]
            
            pdb_file = None
            for pattern in pdb_patterns:
                if pattern.exists():
                    pdb_file = pattern
                    break
            
            if pdb_file:
                center = UniversalFpocketParser.calculate_pocket_center(pdb_file)
                pocket['center_x'], pocket['center_y'], pocket['center_z'] = center
                pocket['pdb_file'] = str(pdb_file)
            else:
                print(f"警告: 未找到口袋{pocket_id}的PDB文件")
                pocket['center_x'], pocket['center_y'], pocket['center_z'] = [0.0, 0.0, 0.0]
            
            # 添加构象信息
            pocket['conformation'] = name
            pocket['weight'] = weight
            pocket['source_dir'] = str(fpocket_dir)
        
        return pockets
    
    @staticmethod
    def auto_discover_conformations(base_dir, pattern="*_out"):
        """自动发现构象目录"""
        base_path = Path(base_dir)
        conformation_dirs = sorted(list(base_path.glob(pattern)))
        
        if not conformation_dirs:
            # 尝试其他常见模式
            conformation_dirs = sorted(list(base_path.glob("*/")))
            conformation_dirs = [d for d in conformation_dirs if d.is_dir()]
        
        print(f"在 {base_dir} 中发现 {len(conformation_dirs)} 个构象目录")
        
        return [str(d) for d in conformation_dirs]


class UniversalHiddenPocketAnalyzer:
    """通用隐藏口袋分析器"""
    
    def __init__(self, eps=6.0, min_score=0.0):
        """初始化分析器"""
        self.eps = eps  # DBSCAN距离阈值
        self.min_score = min_score
        self.all_pockets = []
        self.clusters = []
        self.hidden_pockets = []
        self.conformation_stats = {}
        
    def add_conformation(self, pockets, name, weight):
        """添加一个构象的口袋数据"""
        if not pockets:
            print(f"警告: 构象 {name} 没有口袋数据")
            return
        
        # 存储构象统计
        self.conformation_stats[name] = {
            'weight': weight,
            'total_pockets': len(pockets),
            'scores': [p.get('score', 0) for p in pockets],
            'volumes': [p.get('volume', 0) for p in pockets],
            'druggabilities': [p.get('druggability', 0) for p in pockets]
        }
        
        # 添加口袋到总列表
        for pocket in pockets:
            if pocket.get('score', -999) >= self.min_score:
                pocket['conformation_name'] = name
                pocket['conformation_weight'] = weight
                self.all_pockets.append(pocket)
    
    def cluster_pockets(self, adaptive_eps=True):
        """基于空间位置对口袋进行聚类"""
        if not self.all_pockets:
            print("错误: 没有口袋数据")
            return []
        
        # 提取所有口袋的中心坐标
        centers = np.array([
            [p['center_x'], p['center_y'], p['center_z']] 
            for p in self.all_pockets
        ])
        
        # 自适应调整eps
        if adaptive_eps and len(centers) > 1:
            from scipy.spatial.distance import pdist
            distances = pdist(centers)
            if len(distances) > 0:
                eps = np.percentile(distances, 25)  # 使用25%分位数
                eps = max(4.0, min(eps, 15.0))  # 限制在合理范围
                print(f"自适应聚类阈值: {eps:.2f}Å (原设定: {self.eps}Å)")
                self.eps = eps
        
        # 使用DBSCAN进行聚类
        clustering = DBSCAN(eps=self.eps, min_samples=1).fit(centers)
        labels = clustering.labels_
        
        # 组织聚类结果
        n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
        n_noise = list(labels).count(-1)
        print(f"找到 {n_clusters} 个口袋簇 (噪声点: {n_noise})")
        
        # 按簇组织口袋
        self.clusters = []
        for cluster_id in set(labels):
            if cluster_id == -1:
                continue  # 忽略噪声点
            
            cluster_pockets = []
            for i, label in enumerate(labels):
                if label == cluster_id:
                    cluster_pockets.append(self.all_pockets[i])
            
            if cluster_pockets:
                # 计算簇的中心
                cluster_centers = np.array([
                    [p['center_x'], p['center_y'], p['center_z']] 
                    for p in cluster_pockets
                ])
                cluster_center = np.mean(cluster_centers, axis=0).tolist()
                
                # 计算簇的各种统计量
                scores = [p.get('score', 0) for p in cluster_pockets]
                volumes = [p.get('volume', 0) for p in cluster_pockets]
                druggabilities = [p.get('druggability', 0) for p in cluster_pockets]
                conformations = list(set([p['conformation_name'] for p in cluster_pockets]))
                weights = [p['conformation_weight'] for p in cluster_pockets]
                
                # 加权平均评分
                weighted_score = np.average(scores, weights=weights)
                
                self.clusters.append({
                    'cluster_id': cluster_id,
                    'pockets': cluster_pockets,
                    'center': cluster_center,
                    'conformations': conformations,
                    'num_conformations': len(conformations),
                    'num_pockets': len(cluster_pockets),
                    'avg_score': np.mean(scores),
                    'weighted_score': weighted_score,
                    'max_score': np.max(scores),
                    'avg_volume': np.mean(volumes),
                    'avg_druggability': np.mean(druggabilities),
                    'max_druggability': np.max(druggabilities)
                })
        
        return self.clusters
    
    def identify_hidden_pockets(self, min_conformations=1, max_conformations=None):
        """识别隐藏口袋"""
        if max_conformations is None:
            max_conformations = len(self.conformation_stats) - 1
        
        hidden_pockets = []
        
        for cluster in self.clusters:
            num_conformations = cluster['num_conformations']
            
            # 隐藏口袋判断条件
            is_hidden = False
            reasons = []
            
            # 条件1: 不是在所有构象中都出现
            total_conformations = len(self.conformation_stats)
            if num_conformations < total_conformations:
                is_hidden = True
                reasons.append(f"出现在 {num_conformations}/{total_conformations} 个构象中")
            
            # 条件2: 构象数量在指定范围内
            if min_conformations <= num_conformations <= max_conformations:
                is_hidden = True
                reasons.append(f"构象数量在范围 [{min_conformations}, {max_conformations}] 内")
            else:
                is_hidden = False
            
            # 条件3: 高评分
            if cluster['max_score'] > 0.3:
                is_hidden = True
                reasons.append(f"高评分 ({cluster['max_score']:.3f})")
            
            # 条件4: 在次要构象中评分高
            if self._is_high_in_minor_conformations(cluster):
                is_hidden = True
                reasons.append("在次要构象中评分高")
            
            if is_hidden:
                # 分类隐藏口袋类型
                pocket_type = self._classify_hidden_pocket_type(cluster)
                
                # 计算重要性评分
                importance_score = self._calculate_importance_score(cluster)
                
                hidden_pocket = {
                    'cluster_id': cluster['cluster_id'],
                    'type': pocket_type,
                    'importance_score': importance_score,
                    'reasons': reasons,
                    'avg_score': cluster['avg_score'],
                    'weighted_score': cluster['weighted_score'],
                    'max_score': cluster['max_score'],
                    'avg_druggability': cluster['avg_druggability'],
                    'avg_volume': cluster['avg_volume'],
                    'conformations': cluster['conformations'],
                    'num_conformations': num_conformations,
                    'num_pockets': cluster['num_pockets'],
                    'pockets': cluster['pockets']
                }
                
                hidden_pockets.append(hidden_pocket)
        
        # 按重要性评分排序
        hidden_pockets.sort(key=lambda x: x['importance_score'], reverse=True)
        self.hidden_pockets = hidden_pockets
        
        return hidden_pockets
    
    def _is_high_in_minor_conformations(self, cluster):
        """检查是否在次要构象中评分高"""
        # 定义次要构象（权重较低的构象）
        min_weight = min(stat['weight'] for stat in self.conformation_stats.values())
        minor_threshold = min_weight * 3  # 权重小于3倍最小权重的构象
        
        minor_scores = []
        for pocket in cluster['pockets']:
            if self.conformation_stats[pocket['conformation_name']]['weight'] < minor_threshold:
                minor_scores.append(pocket.get('score', 0))
        
        if minor_scores:
            return np.mean(minor_scores) > 0.3
        return False
    
    def _classify_hidden_pocket_type(self, cluster):
        """分类隐藏口袋类型"""
        num_conformations = cluster['num_conformations']
        total_conformations = len(self.conformation_stats)
        
        if num_conformations == 1:
            return "conformation_specific"
        elif num_conformations == total_conformations:
            return "universal"
        elif num_conformations < total_conformations // 2:
            return "rare"
        elif self._is_high_in_minor_conformations(cluster):
            return "minor_conformation_hotspot"
        else:
            return "common"
    
    def _calculate_importance_score(self, cluster):
        """计算综合重要性评分"""
        # 权重分配
        weights = {
            'score': 0.4,
            'conformation_coverage': 0.3,
            'druggability': 0.2,
            'consistency': 0.1
        }
        
        # 评分成分
        score_component = min(cluster['max_score'] / 1.0, 1.0)  # 假设最高分1.0
        
        # 构象覆盖度成分
        total_conformations = len(self.conformation_stats)
        coverage_component = cluster['num_conformations'] / total_conformations
        
        # 药物性成分
        druggability_component = min(cluster['avg_druggability'] / 0.5, 1.0)  # 假设最高0.5
        
        # 一致性成分（评分方差越低越一致）
        scores = [p.get('score', 0) for p in cluster['pockets']]
        consistency_component = 1.0 / (1.0 + np.var(scores)) if len(scores) > 1 else 0.5
        
        # 计算综合评分
        importance_score = (
            score_component * weights['score'] +
            coverage_component * weights['conformation_coverage'] +
            druggability_component * weights['druggability'] +
            consistency_component * weights['consistency']
        )
        
        return importance_score
    
    def generate_report(self, output_dir="universal_hidden_pockets_results"):
        """生成分析报告"""
        os.makedirs(output_dir, exist_ok=True)
        
        # 1. 保存所有口袋数据
        self._save_all_data(output_dir)
        
        # 2. 生成构象统计
        self._save_conformation_stats(output_dir)
        
        # 3. 保存隐藏口袋数据
        if self.hidden_pockets:
            self._save_hidden_pockets(output_dir)
        
        # 4. 生成可视化
        self._create_visualizations(output_dir)
        
        # 5. 生成文本报告
        self._generate_text_report(output_dir)
        
        print(f"报告已保存到: {output_dir}")
    
    def _save_all_data(self, output_dir):
        """保存所有口袋数据"""
        all_data = []
        for pocket in self.all_pockets:
            all_data.append({
                'pocket_id': pocket.get('pocket_id', 'N/A'),
                'conformation': pocket.get('conformation_name', 'N/A'),
                'weight': pocket.get('conformation_weight', 0),
                'score': pocket.get('score', 0),
                'druggability': pocket.get('druggability', 0),
                'volume': pocket.get('volume', 0),
                'center_x': pocket.get('center_x', 0),
                'center_y': pocket.get('center_y', 0),
                'center_z': pocket.get('center_z', 0)
            })
        
        df_all = pd.DataFrame(all_data)
        df_all.to_csv(os.path.join(output_dir, "all_pockets.csv"), index=False)
    
    def _save_conformation_stats(self, output_dir):
        """保存构象统计"""
        stats_data = []
        for name, stats in self.conformation_stats.items():
            if stats['scores']:
                stats_data.append({
                    'conformation': name,
                    'weight': stats['weight'],
                    'num_pockets': stats['total_pockets'],
                    'avg_score': np.mean(stats['scores']),
                    'max_score': np.max(stats['scores']),
                    'avg_volume': np.mean(stats['volumes']),
                    'avg_druggability': np.mean(stats['druggabilities'])
                })
        
        if stats_data:
            df_stats = pd.DataFrame(stats_data)
            df_stats.to_csv(os.path.join(output_dir, "conformation_statistics.csv"), index=False)
    
    def _save_hidden_pockets(self, output_dir):
        """保存隐藏口袋数据"""
        # 详细数据
        hidden_data = []
        for i, hp in enumerate(self.hidden_pockets, 1):
            for pocket in hp['pockets']:
                hidden_data.append({
                    'hidden_pocket_id': i,
                    'type': hp['type'],
                    'importance_score': hp['importance_score'],
                    'conformation': pocket.get('conformation_name', 'N/A'),
                    'pocket_id': pocket.get('pocket_id', 'N/A'),
                    'score': pocket.get('score', 0),
                    'druggability': pocket.get('druggability', 0),
                    'volume': pocket.get('volume', 0),
                    'center_x': pocket.get('center_x', 0),
                    'center_y': pocket.get('center_y', 0),
                    'center_z': pocket.get('center_z', 0),
                    'reasons': '; '.join(hp['reasons'])
                })
        
        df_hidden = pd.DataFrame(hidden_data)
        df_hidden.to_csv(os.path.join(output_dir, "hidden_pockets.csv"), index=False)
        
        # 摘要数据
        summary_data = []
        for i, hp in enumerate(self.hidden_pockets, 1):
            summary_data.append({
                'hidden_pocket_id': i,
                'type': hp['type'],
                'importance_score': hp['importance_score'],
                'conformations': ', '.join(hp['conformations']),
                'num_conformations': hp['num_conformations'],
                'avg_score': hp['avg_score'],
                'weighted_score': hp['weighted_score'],
                'max_score': hp['max_score'],
                'avg_druggability': hp['avg_druggability'],
                'avg_volume': hp['avg_volume'],
                'num_pockets': hp['num_pockets'],
                'reasons': '; '.join(hp['reasons'])
            })
        
        df_summary = pd.DataFrame(summary_data)
        df_summary.to_csv(os.path.join(output_dir, "hidden_pockets_summary.csv"), index=False)
    
    def _create_visualizations(self, output_dir):
        """创建可视化图表"""
        if not self.all_pockets:
            return
        
        # 创建多个图表
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # 1. 各构象口袋数量
        conf_counts = defaultdict(int)
        for p in self.all_pockets:
            conf_counts[p['conformation_name']] += 1
        
        colors = plt.cm.Set3(np.linspace(0, 1, len(conf_counts)))
        axes[0, 0].bar(conf_counts.keys(), conf_counts.values(), color=colors)
        axes[0, 0].set_title('各构象口袋数量')
        axes[0, 0].set_xlabel('构象')
        axes[0, 0].set_ylabel('口袋数量')
        axes[0, 0].tick_params(axis='x', rotation=45)
        
        # 2. 各构象平均评分
        conf_scores = defaultdict(list)
        for p in self.all_pockets:
            conf_scores[p['conformation_name']].append(p.get('score', 0))
        
        avg_scores = {k: np.mean(v) for k, v in conf_scores.items()}
        colors = plt.cm.Set2(np.linspace(0, 1, len(avg_scores)))
        axes[0, 1].bar(avg_scores.keys(), avg_scores.values(), color=colors)
        axes[0, 1].set_title('各构象平均评分')
        axes[0, 1].set_xlabel('构象')
        axes[0, 1].set_ylabel('平均评分')
        axes[0, 1].tick_params(axis='x', rotation=45)
        
        # 3. 口袋评分分布
        scores = [p.get('score', 0) for p in self.all_pockets]
        axes[0, 2].hist(scores, bins=20, alpha=0.7, edgecolor='black', color='skyblue')
        axes[0, 2].axvline(x=self.min_score, color='r', linestyle='--', label=f'筛选阈值: {self.min_score}')
        axes[0, 2].set_title('口袋评分分布')
        axes[0, 2].set_xlabel('评分')
        axes[0, 2].set_ylabel('数量')
        axes[0, 2].legend()
        
        # 4. 隐藏口袋类型分布（如果有隐藏口袋）
        if self.hidden_pockets:
            type_counts = Counter([hp['type'] for hp in self.hidden_pockets])
            
            colors = plt.cm.Pastel1(np.linspace(0, 1, len(type_counts)))
            wedges, texts, autotexts = axes[1, 0].pie(
                type_counts.values(), 
                labels=type_counts.keys(), 
                autopct='%1.1f%%',
                colors=colors,
                startangle=90
            )
            axes[1, 0].set_title('隐藏口袋类型分布')
        
        # 5. 隐藏口袋重要性评分分布
        if self.hidden_pockets:
            importance_scores = [hp['importance_score'] for hp in self.hidden_pockets]
            axes[1, 1].hist(importance_scores, bins=10, alpha=0.7, edgecolor='black', color='lightgreen')
            axes[1, 1].set_title('隐藏口袋重要性评分分布')
            axes[1, 1].set_xlabel('重要性评分')
            axes[1, 1].set_ylabel('数量')
        
        # 6. 口袋体积分布
        volumes = [p.get('volume', 0) for p in self.all_pockets]
        axes[1, 2].hist(volumes, bins=20, alpha=0.7, edgecolor='black', color='lightcoral')
        axes[1, 2].set_title('口袋体积分布')
        axes[1, 2].set_xlabel('体积 (Å³)')
        axes[1, 2].set_ylabel('数量')
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, "analysis_overview.png"), dpi=300)
        plt.close()
        
        # 创建构象间关系图
        self._create_conformation_relationship_plot(output_dir)
    
    def _create_conformation_relationship_plot(self, output_dir):
        """创建构象间关系图"""
        if len(self.conformation_stats) < 2:
            return
        
        # 创建构象相似性矩阵
        conf_names = list(self.conformation_stats.keys())
        n_confs = len(conf_names)
        
        # 计算构象间口袋相似性（简化的基于共同口袋簇）
        similarity_matrix = np.zeros((n_confs, n_confs))
        
        for i, conf1 in enumerate(conf_names):
            for j, conf2 in enumerate(conf_names):
                if i == j:
                    similarity_matrix[i, j] = 1.0
                elif i < j:
                    # 计算两个构象在相同簇中的口袋比例
                    shared_clusters = 0
                    total_clusters = 0
                    
                    for cluster in self.clusters:
                        confs_in_cluster = cluster['conformations']
                        if conf1 in confs_in_cluster and conf2 in confs_in_cluster:
                            shared_clusters += 1
                        if conf1 in confs_in_cluster or conf2 in confs_in_cluster:
                            total_clusters += 1
                    
                    if total_clusters > 0:
                        similarity = shared_clusters / total_clusters
                        similarity_matrix[i, j] = similarity
                        similarity_matrix[j, i] = similarity
        
        # 绘制热图
        fig, ax = plt.subplots(figsize=(10, 8))
        im = ax.imshow(similarity_matrix, cmap='YlOrRd', vmin=0, vmax=1)
        
        # 设置坐标轴
        ax.set_xticks(np.arange(n_confs))
        ax.set_yticks(np.arange(n_confs))
        ax.set_xticklabels(conf_names, rotation=45, ha='right')
        ax.set_yticklabels(conf_names)
        
        # 添加数值标签
        for i in range(n_confs):
            for j in range(n_confs):
                text = ax.text(j, i, f'{similarity_matrix[i, j]:.2f}',
                              ha="center", va="center", color="black", fontsize=9)
        
        ax.set_title('构象间口袋相似性矩阵')
        plt.colorbar(im, ax=ax, label='相似度')
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, "conformation_similarity.png"), dpi=300)
        plt.close()
    
    def _generate_text_report(self, output_dir):
        """生成文本报告"""
        report_file = os.path.join(output_dir, "report.txt")
        
        with open(report_file, 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("                   通用隐藏口袋分析报告\n")
            f.write("=" * 80 + "\n\n")
            
            f.write(f"分析时间: {pd.Timestamp.now()}\n")
            f.write(f"分析参数:\n")
            f.write(f"  聚类距离阈值(eps): {self.eps} Å\n")
            f.write(f"  评分筛选阈值(min_score): {self.min_score}\n")
            f.write(f"  构象数量: {len(self.conformation_stats)}\n\n")
            
            f.write(f"数据统计:\n")
            f.write(f"  总口袋数: {len(self.all_pockets)}\n")
            f.write(f"  识别口袋簇数: {len(self.clusters)}\n")
            f.write(f"  发现隐藏口袋数: {len(self.hidden_pockets)}\n\n")
            
            f.write("-" * 80 + "\n")
            f.write("构象统计:\n")
            f.write("-" * 80 + "\n")
            
            for name, stats in self.conformation_stats.items():
                f.write(f"{name}:\n")
                f.write(f"  权重: {stats['weight']}\n")
                f.write(f"  口袋数量: {stats['total_pockets']}\n")
                if stats['scores']:
                    f.write(f"  平均评分: {np.mean(stats['scores']):.3f}\n")
                    f.write(f"  最高评分: {np.max(stats['scores']):.3f}\n")
                f.write("\n")
            
            f.write("-" * 80 + "\n")
            f.write("隐藏口袋详细列表 (按重要性排序):\n")
            f.write("-" * 80 + "\n\n")
            
            if self.hidden_pockets:
                for i, hp in enumerate(self.hidden_pockets, 1):
                    f.write(f"隐藏口袋 #{i}:\n")
                    f.write(f"  类型: {hp['type']}\n")
                    f.write(f"  重要性评分: {hp['importance_score']:.3f}\n")
                    f.write(f"  出现的构象: {', '.join(hp['conformations'])} ({hp['num_conformations']}个)\n")
                    f.write(f"  平均评分: {hp['avg_score']:.3f}\n")
                    f.write(f"  加权评分: {hp['weighted_score']:.3f}\n")
                    f.write(f"  最高评分: {hp['max_score']:.3f}\n")
                    f.write(f"  平均药物性: {hp['avg_druggability']:.3f}\n")
                    f.write(f"  平均体积: {hp['avg_volume']:.1f} Å³\n")
                    f.write(f"  识别原因: {'; '.join(hp['reasons'])}\n")
                    
                    # 显示每个构象的具体信息
                    f.write(f"  各构象详情:\n")
                    for pocket in hp['pockets']:
                        f.write(f"    - {pocket['conformation_name']} 口袋{pocket.get('pocket_id', 'N/A')}: "
                               f"评分={pocket.get('score', 0):.3f}, "
                               f"药物性={pocket.get('druggability', 0):.3f}, "
                               f"体积={pocket.get('volume', 0):.1f}Å³\n")
                    
                    f.write("\n")
            else:
                f.write("未发现符合标准的隐藏口袋\n\n")
            
            f.write("=" * 80 + "\n")
            f.write("报告结束\n")
            f.write("=" * 80 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description='通用多构象隐藏口袋识别与分析',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 方式1: 直接指定构象目录
  python universal_hidden_pocket_analyzer.py dir1 dir2 dir3 dir4
  
  # 方式2: 指定权重和名称
  python universal_hidden_pocket_analyzer.py dir1 dir2 dir3 \\
      --weights 314 12 7 2 \\
      --names main minor1 minor2 minor3
  
  # 方式3: 自动发现构象
  python universal_hidden_pocket_analyzer.py --auto-discover ./results
  
  # 方式4: 使用配置文件
  python universal_hidden_pocket_analyzer.py --config config.json
        """
    )
    
    # 输入方式选择
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument('dirs', nargs='*', help='构象的fpocket输出目录列表')
    input_group.add_argument('--auto-discover', metavar='BASE_DIR', 
                           help='自动发现构象目录（在指定目录中查找*_out模式）')
    input_group.add_argument('--config', help='配置文件路径（JSON格式）')
    
    # 参数选项
    parser.add_argument('--weights', nargs='*', type=float, 
                       help='对应构象的权重列表（长度必须与目录数相同）')
    parser.add_argument('--names', nargs='*', 
                       help='对应构象的名称列表（长度必须与目录数相同）')
    parser.add_argument('--eps', type=float, default=6.0,
                       help='DBSCAN聚类距离阈值(Å)（默认: 6.0）')
    parser.add_argument('--min-score', type=float, default=0.0,
                       help='口袋评分筛选阈值（默认: 0.0）')
    parser.add_argument('--output', default='universal_hidden_pockets_results',
                       help='输出目录（默认: universal_hidden_pockets_results）')
    parser.add_argument('--verbose', action='store_true', help='详细输出模式')
    
    args = parser.parse_args()
    
    # 确定构象目录列表
    conformation_dirs = []
    
    if args.auto_discover:
        print(f"自动发现构象目录: {args.auto_discover}")
        conformation_dirs = UniversalFpocketParser.auto_discover_conformations(args.auto_discover)
    elif args.config:
        print(f"使用配置文件: {args.config}")
        with open(args.config, 'r') as f:
            config = json.load(f)
            conformation_dirs = config.get('dirs', [])
            args.weights = config.get('weights', args.weights)
            args.names = config.get('names', args.names)
    else:
        conformation_dirs = args.dirs
    
    if not conformation_dirs:
        print("错误: 没有找到构象目录")
        return
    
    # 验证目录存在
    for d in conformation_dirs:
        if not os.path.exists(d):
            print(f"错误: 目录不存在: {d}")
            return
    
    # 确定权重和名称
    n_conformations = len(conformation_dirs)
    
    if args.weights:
        if len(args.weights) != n_conformations:
            print(f"错误: 权重数量({len(args.weights)})与构象数量({n_conformations})不匹配")
            return
        weights = args.weights
    else:
        # 默认权重为1
        weights = [1.0] * n_conformations
    
    if args.names:
        if len(args.names) != n_conformations:
            print(f"错误: 名称数量({len(args.names)})与构象数量({n_conformations})不匹配")
            return
        names = args.names
    else:
        # 使用目录名作为名称
        names = [Path(d).name for d in conformation_dirs]
    
    print("=" * 80)
    print("通用多构象隐藏口袋分析")
    print("=" * 80)
    print(f"构象数量: {n_conformations}")
    
    for i, (dir_path, name, weight) in enumerate(zip(conformation_dirs, names, weights), 1):
        print(f"构象{i}: {name} (权重: {weight}) -> {dir_path}")
    
    print(f"输出目录: {args.output}")
    print(f"聚类参数: eps={args.eps}")
    print(f"评分筛选阈值: {args.min_score}")
    print("=" * 80 + "\n")
    
    # 初始化分析器
    analyzer = UniversalHiddenPocketAnalyzer(eps=args.eps, min_score=args.min_score)
    
    # 解析每个构象
    for i, (dir_path, name, weight) in enumerate(zip(conformation_dirs, names, weights), 1):
        print(f"解析构象 {i}/{n_conformations}: {name} (权重={weight})...")
        
        pockets = UniversalFpocketParser.parse_fpocket_directory(dir_path, weight, name, args.min_score)
        
        print(f"  找到 {len(pockets)} 个口袋 (评分≥{args.min_score})")
        if pockets and args.verbose:
            scores = [p.get('score', 0) for p in pockets]
            print(f"  评分范围: {min(scores):.3f} - {max(scores):.3f}")
            print(f"  平均评分: {np.mean(scores):.3f}")
            print(f"  评分>0.2的口袋: {len([s for s in scores if s > 0.2])}个")
        
        analyzer.add_conformation(pockets, name, weight)
        print()
    
    # 检查是否有足够的口袋数据
    if len(analyzer.all_pockets) == 0:
        print("错误: 没有找到符合条件的口袋，分析终止")
        print("建议: 降低--min-score参数值或检查fpocket输出文件")
        return
    
    print(f"总共收集到 {len(analyzer.all_pockets)} 个口袋")
    
    # 聚类口袋
    print("聚类口袋...")
    clusters = analyzer.cluster_pockets()
    print(f"聚类完成，得到 {len(clusters)} 个口袋簇\n")
    
    # 识别隐藏口袋
    print("识别隐藏口袋...")
    hidden_pockets = analyzer.identify_hidden_pockets()
    print(f"发现 {len(hidden_pockets)} 个隐藏口袋\n")
    
    # 显示隐藏口袋摘要
    if hidden_pockets:
        print("隐藏口袋摘要 (前10个):")
        print("-" * 80)
        
        for i, hp in enumerate(hidden_pockets[:10], 1):
            print(f"{i}. 类型: {hp['type']}")
            print(f"   重要性评分: {hp['importance_score']:.3f}")
            print(f"   构象: {', '.join(hp['conformations'])}")
            print(f"   加权评分: {hp['weighted_score']:.3f} (最高: {hp['max_score']:.3f})")
            print(f"   平均药物性: {hp['avg_druggability']:.3f}")
            print(f"   平均体积: {hp['avg_volume']:.1f} Å³")
            print(f"   原因: {', '.join(hp['reasons'])}")
            print()
        
        if len(hidden_pockets) > 10:
            print(f"... 还有 {len(hidden_pockets)-10} 个隐藏口袋未显示")
        
        print("-" * 80)
        
        # 质量统计
        high_importance = len([hp for hp in hidden_pockets if hp['importance_score'] >= 0.7])
        medium_importance = len([hp for hp in hidden_pockets if 0.5 <= hp['importance_score'] < 0.7])
        
        print(f"重要性统计:")
        print(f"  高重要性(≥0.7): {high_importance} 个")
        print(f"  中等重要性(0.5-0.7): {medium_importance} 个")
        print(f"  低重要性(<0.5): {len(hidden_pockets) - high_importance - medium_importance} 个")
    
    # 生成报告
    print(f"\n生成报告...")
    analyzer.generate_report(args.output)
    
    print(f"\n分析完成！结果保存在: {args.output}")
    print("主要输出文件:")
    print(f"  - {args.output}/all_pockets.csv (所有口袋数据)")
    print(f"  - {args.output}/conformation_statistics.csv (构象统计)")
    print(f"  - {args.output}/hidden_pockets.csv (隐藏口袋数据)")
    print(f"  - {args.output}/hidden_pockets_summary.csv (隐藏口袋摘要)")
    print(f"  - {args.output}/report.txt (文本报告)")
    print(f"  - {args.output}/analysis_overview.png (分析图表)")
    print(f"  - {args.output}/conformation_similarity.png (构象相似性图)")


if __name__ == "__main__":
    main()