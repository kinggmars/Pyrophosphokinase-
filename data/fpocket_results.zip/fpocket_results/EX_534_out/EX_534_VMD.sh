#!/bin/bash
vmd EX_534_out.pdb -e EX_534.tcl
