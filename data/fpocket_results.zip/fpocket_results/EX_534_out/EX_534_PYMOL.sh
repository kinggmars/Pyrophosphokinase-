#!/bin/bash
pymol EX_534.pml
