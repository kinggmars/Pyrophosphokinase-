#!/bin/bash
vmd frame10_out.pdb -e frame10.tcl
