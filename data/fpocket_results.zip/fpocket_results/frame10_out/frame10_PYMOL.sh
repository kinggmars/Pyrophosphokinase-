#!/bin/bash
pymol frame10.pml
