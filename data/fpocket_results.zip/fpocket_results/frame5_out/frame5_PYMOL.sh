#!/bin/bash
pymol frame5.pml
