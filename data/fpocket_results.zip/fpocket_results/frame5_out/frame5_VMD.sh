#!/bin/bash
vmd frame5_out.pdb -e frame5.tcl
