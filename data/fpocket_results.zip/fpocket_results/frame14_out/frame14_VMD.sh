#!/bin/bash
vmd frame14_out.pdb -e frame14.tcl
