#!/bin/bash
pymol frame14.pml
