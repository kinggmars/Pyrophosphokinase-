#!/bin/bash
pymol frame11.pml
