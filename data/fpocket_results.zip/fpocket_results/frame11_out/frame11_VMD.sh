#!/bin/bash
vmd frame11_out.pdb -e frame11.tcl
