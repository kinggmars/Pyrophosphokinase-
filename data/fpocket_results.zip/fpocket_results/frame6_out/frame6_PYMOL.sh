#!/bin/bash
pymol frame6.pml
