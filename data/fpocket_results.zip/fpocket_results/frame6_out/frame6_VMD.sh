#!/bin/bash
vmd frame6_out.pdb -e frame6.tcl
