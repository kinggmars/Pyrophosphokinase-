#!/bin/bash
vmd frame1_out.pdb -e frame1.tcl
