#!/bin/bash
pymol frame1.pml
