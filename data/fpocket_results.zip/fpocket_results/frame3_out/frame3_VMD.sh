#!/bin/bash
vmd frame3_out.pdb -e frame3.tcl
