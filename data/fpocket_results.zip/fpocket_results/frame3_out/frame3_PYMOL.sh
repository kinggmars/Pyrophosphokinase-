#!/bin/bash
pymol frame3.pml
